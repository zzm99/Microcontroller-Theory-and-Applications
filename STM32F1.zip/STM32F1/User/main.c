/********************************************************************************
* @file    main.c
* @author  Oslomayor
* @date    2018-7-12
*
* Wechat Offical Account: CrazyEngineer
* GitHub  : https://github.com/Oslomayor
* CSDN    : https://blog.csdn.net/weixin_42602730
********************************************************************************/  


#include "stm32f10x.h"



int main()
{
	uint32_t i = 0;
	uint32_t j = 0;
	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;//???????GPIOB??	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//?????????????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//???????50MHZ
	GPIO_Init(GPIOC, &GPIO_InitStructure);

  while(1){
		for(i=0;i<0xffff;i++)
			for(j=0;j<0xf;j++);
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
		for(i=0;i<0xffff;i++)
			for(j=0;j<0xf;j++);
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
  return 0;
}
